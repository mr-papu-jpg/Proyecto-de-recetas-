angular.module('RecipeApp', [])
.controller('RecipeController', function($scope, $http, $interval) {
    
    // --- Modelos ---
    $scope.recipes = [];
    $scope.newRecipe = {};
    $scope.loadingError = false;
    $scope.submitting = false;
    $scope.pendingCount = 0; // Contador de items pendientes

    // --- Funciones de Caché Local (localStorage) ---

    // 1. Cargar pendientes del localStorage
    function loadPending() {
        try {
            const pending = JSON.parse(localStorage.getItem('pendingRecipes') || '[]');
            return pending;
        } catch (e) {
            console.error('Error al cargar pendientes:', e);
            return [];
        }
    }

    // 2. Guardar pendientes en el localStorage
    function savePending(pending) {
        localStorage.setItem('pendingRecipes', JSON.stringify(pending));
        $scope.pendingCount = pending.length;
    }

    // --- Sincronización (El Punto Clave) ---

    $scope.syncPending = function() {
        let pending = loadPending();
        $scope.pendingCount = pending.length;

        if (pending.length === 0) return;

        console.log(`Intentando sincronizar ${pending.length} receta(s) pendiente(s)...`);

        // Procesar la primera receta pendiente (solo una a la vez para evitar sobrecarga)
        const recipeToSync = pending[0];
        $http.post('/api/recipes', recipeToSync)
            .then(function(response) {
                console.log('Receta sincronizada con éxito:', response.data);
                
                // Si la sincronización es exitosa, la eliminamos de la lista
                pending = pending.slice(1);
                savePending(pending);

                // Recargamos la lista principal para mostrar el nuevo item
                $scope.loadRecipes(); 
            })
            .catch(function(error) {
                console.warn('Fallo de sincronización. Servidor inalcanzable.', error.status);
                // Si falla, no hacemos nada, se mantendrá en el localStorage para el próximo intento
            });
    };

    // --- Funcionalidad CRUD (Crear) ---

    $scope.createRecipe = function() {
        if (!$scope.newRecipe.name || !$scope.newRecipe.prepTime) return;

        $scope.submitting = true;
        
        $http.post('/api/recipes', $scope.newRecipe)
            .then(function(response) {
                // 1. Éxito: Agregamos la nueva receta a la vista
                $scope.recipes.push(response.data);
                console.log('Receta creada directamente en el backend:', response.data);
            })
            .catch(function(error) {
                // 2. Falla (Estamos Offline/Backend caído): Guardamos en caché
                console.warn('Backend inalcanzable. Guardando en caché local.');
                
                let pending = loadPending();
                const tempId = Date.now().toString(); // ID temporal para el caché
                
                pending.push({ ...$scope.newRecipe, id: tempId });
                savePending(pending);
                
                alert('Receta guardada localmente. Se sincronizará cuando el servidor esté activo.');
            })
            .finally(function() {
                // 3. Limpieza: Resetear formulario y estado
                $scope.newRecipe = {};
                $scope.submitting = false;
            });
    };


    // --- Inicialización ---

    // Función para obtener las recetas de la API de Node.js
    $scope.loadRecipes = function() {
        $http.get('/api/recipes')
            .then(function(response) {
                $scope.recipes = response.data;
                $scope.loadingError = false;
            })
            .catch(function(error) {
                $scope.loadingError = true;
                console.error('Error al cargar las recetas:', error);
            });
    };

    // Cargar pendientes y recetas al inicio
    loadPending();
    $scope.loadRecipes();

    // Sincronizar cada 10 segundos
    $interval($scope.syncPending, 10000);
});

