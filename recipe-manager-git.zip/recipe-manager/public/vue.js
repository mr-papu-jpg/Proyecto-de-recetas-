new Vue({
    el: '#app', 
    data: {
        recipes: [], 
        currentRecipe: { name: '', prepTime: '' }, // Modelo para el formulario
        loadingError: false, 
        isEditing: false, // Bandera para saber si estamos creando o editando
        submitting: false
    },
    methods: {
        // --- Cargar Recetas (READ) ---
        loadRecipes: function() {
            axios.get('/api/recipes')
                .then(response => {
                    this.recipes = response.data;
                    this.loadingError = false;
                    console.log('Recetas cargadas (Vue):', this.recipes);
                })
                .catch(error => {
                    this.loadingError = true;
                    console.error('Error al cargar las recetas (Vue):', error);
                });
        },
        
        // --- Guardar/Actualizar Receta (CREATE/UPDATE) ---
        saveRecipe: function() {
            this.submitting = true;
            let promise;

            if (this.isEditing) {
                // UPDATE (PUT)
                const id = this.currentRecipe.id;
                promise = axios.put(`/api/recipes/${id}`, this.currentRecipe);
            } else {
                // CREATE (POST)
                promise = axios.post('/api/recipes', this.currentRecipe);
            }

            promise
                .then(response => {
                    // Recargar la lista después de crear/actualizar
                    this.loadRecipes(); 
                    
                    // Limpiar el formulario y el estado
                    this.cancelEdit();
                    console.log('Receta guardada/actualizada con éxito:', response.data);
                })
                .catch(error => {
                    alert(`Error al guardar la receta: ${error.message}. Verifique el backend.`);
                })
                .finally(() => {
                    this.submitting = false;
                });
        },

        // --- Editar Receta (UPDATE Preparación) ---
        editRecipe: function(recipe) {
            this.isEditing = true;
            // Clonar el objeto para que los cambios en el formulario no afecten la lista inmediatamente
            this.currentRecipe = { ...recipe }; 
        },

        // --- Cancelar Edición ---
        cancelEdit: function() {
            this.isEditing = false;
            this.currentRecipe = { name: '', prepTime: '' }; // Limpiar modelo
        },

        // --- Eliminar Receta (DELETE) ---
        deleteRecipe: function(id) {
            if (!confirm('¿Estás seguro de que quieres eliminar esta receta?')) {
                return;
            }
            axios.delete(`/api/recipes/${id}`)
                .then(() => {
                    console.log('Receta eliminada:', id);
                    // Actualizar la lista en la vista
                    this.recipes = this.recipes.filter(r => r.id !== id);
                })
                .catch(error => {
                    alert(`Error al eliminar la receta: ${error.message}`);
                });
        }
    },
    
    // Inicialización
    mounted() {
        this.loadRecipes();
    }
});

