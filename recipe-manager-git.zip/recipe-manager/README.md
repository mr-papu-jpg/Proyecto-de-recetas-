# 👨‍💻 Gestor de Recetas Multi-Frontend (Node.js + LowDB + AngularJS + Vue.js)

Este proyecto es una demostración de una arquitectura ligera y moderna, ideal para entornos como Termux, combinando Backend (Node.js) con dos Frontends distintos (AngularJS y Vue.js) que consumen la misma API.

## 🚀 Tecnologías Utilizadas

**Backend:**
* Node.js (v24+)
* **Express:** Servidor minimalista.
* **LowDB:** Base de datos NoSQL basada en archivos JSON (`db.json`).
* CORS: Habilitado para comunicación frontend/backend.

**Frontend:**
* **AngularJS (v1.8.2):** Implementación de la lista de recetas y la lógica de **Caché Local/Offline** (usando `localStorage`).
* **Vue.js (v2.x):** Implementación del **CRUD completo (Crear, Actualizar, Eliminar)**.

## ⚙️ Configuración y Ejecución

Este proyecto está diseñado para funcionar en un entorno Node.js, como Termux o cualquier servidor local.

1.  **Requisitos Previos (Termux/Linux):**
    Asegúrate de tener Node.js y npm instalados.
    ```bash
    pkg install nodejs
    ```

2.  **Clonar y Navegar:**
    ```bash
    git clone [TU URL DE REPOSITORIO]
    cd recipe-manager
    ```

3.  **Instalar Dependencias de Node.js (node_modules):**
    Este comando descargará y configurará las dependencias ligeras (`express`, `lowdb`, `cors`) necesarias para el Backend.
    ```bash
    npm install
    ```

4.  **Iniciar el Servidor:**
    ```bash
    node server.js
    ```
    El servidor se ejecutará en **http://localhost:3000**.

5.  **Acceder a la Aplicación:**
    * **AngularJS (Offline/Cache Demo):** Abre tu navegador en `http://localhost:3000/`
    * **Vue.js (CRUD Completo):** Abre tu navegador en `http://localhost:3000/vue.html`

¡Disfruta probando la comunicación perfecta entre estas tecnologías!
