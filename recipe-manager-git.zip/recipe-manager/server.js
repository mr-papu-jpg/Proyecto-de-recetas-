import express from 'express';
import cors from 'cors';
import { join } from 'path';
import { Low } from 'lowdb';
import { JSONFile } from 'lowdb/node';
import crypto from 'crypto'; 

// --- 1. Configuración de LowDB ---
const file = join(process.cwd(), 'db.json');
const adapter = new JSONFile(file);
const db = new Low(adapter, { recipes: [] }); 

await db.read(); 

// --- 2. Configuración de Express ---
const app = express();
const PORT = 3000;

app.use(cors()); // <-- AÑADIR ESTA LÍNEA
app.use(express.json());
app.use(express.static('public')); 

// --- 3. Endpoints de la API Mínima (/api/recipes) ---

// GET /api/recipes - Obtener todas las recetas
app.get('/api/recipes', (req, res) => {
  res.json(db.data.recipes);
});

// GET /api/recipes/:id - Obtener una receta por ID
app.get('/api/recipes/:id', (req, res) => {
  const recipe = db.data.recipes.find(r => r.id === req.params.id);
  if (recipe) {
    res.json(recipe);
  } else {
    res.status(404).send({ message: 'Receta no encontrada' });
  }
});

// POST /api/recipes - Crear una nueva receta
app.post('/api/recipes', async (req, res) => {
  const newRecipe = {
    id: crypto.randomBytes(16).toString('hex'), 
    ...req.body
  };

  db.data.recipes.push(newRecipe);
  await db.write(); 
  res.status(201).json(newRecipe);
});

// PUT /api/recipes/:id - Actualizar una receta existente
app.put('/api/recipes/:id', async (req, res) => {
  const index = db.data.recipes.findIndex(r => r.id === req.params.id);

  if (index !== -1) {
    db.data.recipes[index] = { ...db.data.recipes[index], ...req.body };
    await db.write();
    res.json(db.data.recipes[index]);
  } else {
    res.status(404).send({ message: 'Receta no encontrada para actualizar' });
  }
});

// DELETE /api/recipes/:id - Eliminar una receta
app.delete('/api/recipes/:id', async (req, res) => {
  const initialLength = db.data.recipes.length;
  db.data.recipes = db.data.recipes.filter(r => r.id !== req.params.id);

  if (db.data.recipes.length < initialLength) {
    await db.write();
    res.status(204).send(); 
  } else {
    res.status(404).send({ message: 'Receta no encontrada para eliminar' });
  }
});

// --- 4. Inicio del Servidor ---
app.listen(PORT, () => {
  console.log(`🚀 Servidor Node.js (LowDB) corriendo en http://localhost:${PORT}`);
  console.log('Endpoints disponibles: /api/recipes');
});
